# Authentic Naturals — website source

Static website repository, ready for GitHub Pages.

## Contents
- `index.html`: cinematic homepage with original hero video and synchronized sound toggle
- `shop.html`: product catalog
- `product.html`: 100 ml hair oil detail page
- `style.css`: responsive styling
- `app.js`: scrolling scenes, ingredient tabs, audio toggle, cart
- `assets/`: original product visuals, ingredients illustrations, and video

## Local preview
Run `python3 -m http.server 8000` from this folder and open `http://localhost:8000`.

## Publish to GitHub Pages
1. Create a public GitHub repository called `authentic-naturals-website`.
2. Upload **all files and the assets folder**, keeping `index.html` at the repository root.
3. Open Settings > Pages; choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
4. When GitHub finishes deploying, the URL will usually be `https://YOUR-USERNAME.github.io/authentic-naturals-website/`. Replace YOUR-USERNAME with your real GitHub username. This is a template, not a deployed URL.

## Important limitations
- Browsers usually block autoplay with audio. Video autoplays muted and users select **Play with Sound** to hear the original track. The video itself and its sound are synchronized.
- Ingredient photos are illustrative until the owner confirms the full formula; do not advertise them as confirmed contents.
- The cart is a front-end order-enquiry prototype. There is no secure payment processing or order database.
- The website has not been tested in a real mobile browser or deployed to GitHub in this environment.
- No invented GitHub account, URL, or live site is included.
