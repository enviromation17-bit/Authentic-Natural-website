document.addEventListener('DOMContentLoaded', () => {
  // 1. SCROLL-DRIVEN ARCHITECTURAL CAMERA SCRUB ENGINE
  const scrubContainer = document.getElementById('scrubContainer');
  const cameraLens = document.getElementById('cameraLens');
  const hudProgressBar = document.getElementById('hudProgressBar');
  const hudFrameCounter = document.getElementById('hudFrameCounter');
  const hudChapterCounter = document.getElementById('hudChapterCounter');

  // HUD Elements to update on chapter switch
  const hudProjectLabel = document.getElementById('hudProjectLabel');
  const hudDim = document.getElementById('hudDim');
  const hudElevation = document.getElementById('hudElevation');
  const hudMaterial = document.getElementById('hudMaterial');
  const hudChapterCode = document.getElementById('hudChapterCode');
  const hudChapterSub = document.getElementById('hudChapterSub');
  const hudKicker = document.getElementById('hudKicker');
  const hudTitle = document.getElementById('hudTitle');
  const hudLead = document.getElementById('hudLead');
  const hudUrdu = document.getElementById('hudUrdu');
  const hudRoman = document.getElementById('hudRoman');

  const layers = [
    document.getElementById('layer1'),
    document.getElementById('layer2'),
    document.getElementById('layer3'),
    document.getElementById('layer4')
  ];

  const chapters = [
    {
      proj: 'PROJECT 01 / BOTANICALS',
      dim: 'VOLUME: 100 ML (3.38 FL OZ)',
      elev: 'ELEVATION: ROOT FOLLICLE // MATRIX',
      mat: 'MATERIAL: 100% COLD-INFUSED ORGANIC HERBS',
      code: 'AN-01',
      sub: 'FRONT ELEVATION',
      kicker: '01 // BOTANICAL HARVEST',
      title: 'AUTHENTIC <br><em>NATURALS.</em>',
      lead: 'Homemade herbal hair oil crafted in Pakistan. Scroll down to zoom through extraction, massage ritual, and bottle specifications.',
      urdu: '"بالوں کی آئلنگ روٹین کو بنائیں سمپل اور ایزی — ملیں Authentic Naturals Hair Oil سے"',
      roman: '"Baalon ki oiling routine ko banayein simple aur easy. Homemade herbal care for frizz control & shine."'
    },
    {
      proj: 'EXTRACTION 02 / COLD-INFUSION',
      dim: 'FLOW RATE: VISCOUS RIBBON DISPENSE',
      elev: 'ELEVATION: AMBER OIL / SHALLOW GLASS',
      mat: 'ACTIVE: VITAMIN C + THYMOQUINONE',
      code: 'AN-02',
      sub: 'GOLDEN DROP',
      kicker: '02 // EXTRACTION',
      title: 'A GOLDEN <br><em>DROP.</em>',
      lead: 'Explore the botanical imagery behind this hair-care story. The complete ingredient formula still needs confirmation.',
      urdu: '"گھریلو ہربل کیئر، آملہ اور کلونجی کے قدرتی فوائد کے ساتھ"',
      roman: '"A botanical-inspired hair-care ritual."'
    },
    {
      proj: 'THE RITUAL 03 / ACTIVATION',
      dim: 'DURATION: 5–10 MINUTE MASSAGE',
      elev: 'ELEVATION: SCALP MICROCIRCULATION',
      mat: 'ACTION: TRANSDERMAL FOLLICLE NOURISHMENT',
      code: 'AN-03',
      sub: 'APPLICATION',
      kicker: '03 // THE RITUAL',
      title: 'DEEP ROOT <br><em>MASSAGE.</em>',
      lead: 'Apply to warm scalp in sections. Gently massage with fingertips for 5–10 minutes to awaken dermal papilla circulation.',
      urdu: '"پانچ سے دس منٹ تک ہلکے ہاتھوں سے مساج کریں تاکہ تیل جڑوں تک پہنچے"',
      roman: '"Gently massage with fingertips for 5–10 minutes to awaken blood flow and restore moisture balance."'
    },
    {
      proj: 'SPECIFICATION 04 / PROVENANCE',
      dim: 'PACKAGING: AIRTIGHT GOLD PUMP CARTON',
      elev: 'ORIGIN: LAHORE, PAKISTAN',
      mat: 'CERTIFICATION: 100% ORGANIC BOTANICAL OIL',
      code: 'AN-04',
      sub: 'SIGNATURE BOTTLE',
      kicker: '04 // PACKAGING',
      title: 'BOTTLED IN <br><em>PURITY.</em>',
      lead: 'Protected in our signature 100 ml bottle with precision pump. Explore the original 100 ml Authentic Naturals bottle.',
      urdu: '"آرڈر کرنے کے لیے ابھی میسج کریں اور حاصل کریں 100 فیصد قدرتی تیل"',
      roman: '"100 ml bottle ready for your daily routine. Direct delivery across Pakistan via Facebook message."'
    }
  ];

  let currentChapter = 0;
  let targetProgress = 0;
  let currentProgress = 0;

  // Render Loop with Linear Interpolation for Smooth Scrubbing
  const updateScrub = () => {
    if (scrubContainer) {
      const rect = scrubContainer.getBoundingClientRect();
      const scrollable = scrubContainer.offsetHeight - window.innerHeight;
      const scrolled = -rect.top;
      targetProgress = Math.max(0, Math.min(1, scrolled / scrollable));

      // Damped lerp (0.1) creates that weighty camera drift
      currentProgress += (targetProgress - currentProgress) * 0.1;

      // 1. Camera Zoom & Pan Calculation
      // Matches the zoom-into-model effect from the video
      const scale = 1.0 + currentProgress * 0.65; // scales from 1.0x to 1.65x
      const panY = (currentProgress - 0.5) * -40;  // subtle cinematic tilt
      if (cameraLens) {
        cameraLens.style.transform = `scale(${scale.toFixed(4)}) translateY(${panY.toFixed(2)}px)`;
      }

      // 2. Timeline Bar & Frame Counter
      if (hudProgressBar) {
        hudProgressBar.style.width = `${(currentProgress * 100).toFixed(1)}%`;
      }
      if (hudFrameCounter) {
        const frame = Math.floor(currentProgress * 299) + 1;
        hudFrameCounter.textContent = `FRAME ${String(frame).padStart(3, '0')} // 300`;
      }

      // 3. Chapter Switching & Cross-fade
      const chapIdx = Math.min(3, Math.floor(currentProgress * 4));
      if (chapIdx !== currentChapter) {
        currentChapter = chapIdx;
        const c = chapters[chapIdx];

        // Cross-fade image layers inside viewport
        layers.forEach((l, i) => {
          if (l) l.classList.toggle('active', i === chapIdx);
        });

        // Update HUD typography
        if (hudProjectLabel) hudProjectLabel.textContent = c.proj;
        if (hudDim) hudDim.textContent = c.dim;
        if (hudElevation) hudElevation.textContent = c.elev;
        if (hudMaterial) hudMaterial.textContent = c.mat;
        if (hudChapterCode) hudChapterCode.textContent = c.code;
        if (hudChapterSub) hudChapterSub.textContent = c.sub;
        if (hudKicker) hudKicker.textContent = c.kicker;
        if (hudTitle) hudTitle.innerHTML = c.title;
        if (hudLead) hudLead.textContent = c.lead;
        if (hudUrdu) hudUrdu.textContent = c.urdu;
        if (hudRoman) hudRoman.innerHTML = `<em>${c.roman}</em>`;
        if (hudChapterCounter) hudChapterCounter.textContent = `0${chapIdx + 1} / 04`;
      }
    }
    requestAnimationFrame(updateScrub);
  };
  requestAnimationFrame(updateScrub);

  // 2. PROCEDURAL 60FPS AMBIENT BACKDROP CANVAS
  const canvas = document.getElementById('ambientCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let cw, ch;
    const resizeCanvas = () => {
      cw = canvas.width = window.innerWidth;
      ch = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const particles = Array.from({ length: 35 }, () => ({
      x: Math.random() * cw,
      y: Math.random() * ch,
      r: Math.random() * 80 + 30,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      hue: Math.random() > 0.5 ? 40 : 110
    }));

    const renderCanvas = () => {
      ctx.clearRect(0, 0, cw, ch);
      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < -100) p.x = cw + 100;
        if (p.x > cw + 100) p.x = -100;
        if (p.y < -100) p.y = ch + 100;
        if (p.y > ch + 100) p.y = -100;

        const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r);
        grad.addColorStop(0, `hsla(${p.hue}, 60%, 45%, 0.18)`);
        grad.addColorStop(1, `hsla(${p.hue}, 60%, 45%, 0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
      requestAnimationFrame(renderCanvas);
    };
    renderCanvas();
  }

  // 3. SOUND CONTROLLER — video and soundtrack share one timeline.
  const soundToggle = document.getElementById('soundToggle');
  const soundLabel = document.getElementById('soundLabel');
  const heroVideo = document.getElementById('heroVideo');
  if (soundToggle && heroVideo) {
    soundToggle.addEventListener('click', async () => {
      try {
        if (heroVideo.muted || heroVideo.paused) {
          heroVideo.muted = false;
          heroVideo.volume = 1;
          await heroVideo.play();
        } else {
          heroVideo.muted = true;
        }
        const enabled = !heroVideo.muted;
        soundToggle.classList.toggle('playing', enabled);
        soundToggle.setAttribute('aria-pressed', String(enabled));
        soundLabel.textContent = enabled ? 'MUTE SOUND' : 'PLAY WITH SOUND';
      } catch (error) {
        soundLabel.textContent = 'TAP TO PLAY WITH SOUND';
      }
    });
    heroVideo.play().catch(() => {
      soundLabel.textContent = 'TAP TO PLAY WITH SOUND';
    });
  }

  // 4. BOTANICAL TABS INTERACTION
  const botanicalData = [
    {
      sub: 'SPECIMEN 01 // THE ANCHOR HERB',
      title: 'Amla (Indian Gooseberry)',
      urdu: 'آملہ — قدرتی اینٹی آکسیڈنٹس اور وٹامن سی سے بھرپور',
      body: 'Amla is a botanical known for its antioxidant compounds. Its inclusion in this product has not yet been confirmed.',
      target: 'Root Density & Strength',
      nutrients: 'Vitamin C, Tannins, Flavonoids',
      tag: 'SPECIMEN // AMLA', image: 'assets/ingredient-amla.webp'
    },
    {
      sub: 'SPECIMEN 02 // SEED OF VITALITY',
      title: 'Kalonji (Black Seed)',
      urdu: 'کلونجی — بالوں کی نشوونما اور گھنے پن کے لیے شفاء',
      body: 'Black seed contains naturally occurring compounds including thymoquinone. Its inclusion in this product has not yet been confirmed.',
      target: 'Follicle Reawakening & Thickness',
      nutrients: 'Thymoquinone, Linoleic Acid',
      tag: 'SPECIMEN // KALONJI SEEDS', image: 'assets/ingredient-kalonji.webp'
    },
    {
      sub: 'SPECIMEN 03 // MOISTURE BARRIER',
      title: 'Pure Virgin Coconut Oil',
      urdu: 'خالص ناریل کا تیل — جڑوں میں نمی اور روکھے پن کا خاتمہ',
      body: 'Coconut oil is commonly used to condition hair and reduce moisture loss. Its inclusion in this product has not yet been confirmed.',
      target: 'Frizz Elimination & Cuticle Seal',
      nutrients: 'Lauric Acid, Caprylic Triglycerides',
      tag: 'SPECIMEN // VIRGIN COCONUT', image: 'assets/ingredient-coconut.webp'
    },
    {
      sub: 'SPECIMEN 04 // PROTEIN REBUILDER',
      title: 'Fenugreek (Methi)',
      urdu: 'میتھی دانہ — قدرتی پروٹین اور خشکی سے نجات',
      body: 'Fenugreek is traditionally used in hair-care preparations. Its inclusion in this product has not yet been confirmed.',
      target: 'Cuticle Repair & Flake Defense',
      nutrients: 'Nicotinic Acid, Amino Protein',
      tag: 'SPECIMEN // FENUGREEK SEEDS', image: 'assets/ingredient-fenugreek.webp'
    },
    {
      sub: 'SPECIMEN 05 // CIRCULATION STIMULATOR',
      title: 'Rosemary Extract',
      urdu: 'روزمیری — کھوپڑی میں دورانِ خون اور جڑوں کی مضبوطی',
      body: 'Rosemary is a botanical often discussed in hair-care routines. Confirm that it is in this product before making ingredient claims.',
      target: 'Microcirculation & Hairline Care',
      nutrients: 'Rosmarinic Acid, Carnosic Acid',
      tag: 'SPECIMEN // ROSEMARY ESSENCE', image: 'assets/ingredient-rosemary.webp'
    }
  ];

  const ingSubhead = document.getElementById('ingSubhead');
  const ingTitle = document.getElementById('ingTitle');
  const ingUrdu = document.getElementById('ingUrdu');
  const ingBody = document.getElementById('ingBody');
  const ingTarget = document.getElementById('ingTarget');
  const ingNutrients = document.getElementById('ingNutrients');
  const ingTag = document.getElementById('ingTag');
  const botanicalTabs = document.querySelectorAll('.botanical-tab');
  const ingVisual = document.getElementById('ingVisual');

  botanicalTabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      const idx = parseInt(e.currentTarget.getAttribute('data-idx'), 10);
      const data = botanicalData[idx];
      if (!data) return;

      if (ingVisual) {
        ingVisual.style.opacity = '0.3';
        ingVisual.src = data.image;
        ingVisual.alt = data.title;
        requestAnimationFrame(() => { ingVisual.style.opacity = '1'; });
      }

      if (ingSubhead) ingSubhead.textContent = data.sub;
      if (ingTitle) ingTitle.textContent = data.title;
      if (ingUrdu) ingUrdu.textContent = data.urdu;
      if (ingBody) ingBody.textContent = data.body;
      if (ingTarget) ingTarget.textContent = data.target;
      if (ingNutrients) ingNutrients.textContent = data.nutrients;
      if (ingTag) ingTag.textContent = data.tag;

      botanicalTabs.forEach((b, i) => b.classList.toggle('active', i === idx));
    });
  });

  // 5. SCROLL REVEAL FOR LOWER CARDS
  const revealElements = document.querySelectorAll('.reveal');
  const checkReveal = () => {
    const bottom = window.innerHeight * 0.88;
    revealElements.forEach(el => {
      const top = el.getBoundingClientRect().top;
      if (top < bottom) el.classList.add('visible');
    });
  };
  window.addEventListener('scroll', checkReveal, { passive: true });
  checkReveal();

  // 6. SHOPPING BAG & LOCAL STORAGE ORDER
  const cartDrawer = document.getElementById('cartDrawer');
  const cartOverlay = document.getElementById('cartOverlay');
  const cartClose = document.getElementById('cartClose');
  const cartOpenBtns = document.querySelectorAll('[data-cart-open]');
  const cartCountBadges = document.querySelectorAll('[data-cart-count]');
  const cartLines = document.getElementById('cartLines');
  const checkoutBtn = document.getElementById('checkoutBtn');
  const checkoutMsg = document.getElementById('checkoutMsg');

  let cart = [];
  try {
    const saved = JSON.parse(localStorage.getItem('an_cart') || '[]');
    if (Array.isArray(saved)) cart = saved.filter(i => i && i.id === 'hair-oil-100' && Number.isInteger(i.qty) && i.qty > 0 && i.qty <= 99).map(i => ({id:'hair-oil-100',name:'Authentic Naturals Hair Oil',size:'100 ml',qty:i.qty}));
  } catch (_) { cart = []; }

  const saveCart = () => {
    localStorage.setItem('an_cart', JSON.stringify(cart));
    renderCart();
  };

  const renderCart = () => {
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    cartCountBadges.forEach(b => b.textContent = count);

    if (!cartLines) return;
    if (cart.length === 0) {
      cartLines.innerHTML = '<p style="color: var(--muted); padding: 30px 0;">Your bag is currently empty.</p>';
      return;
    }

    cartLines.innerHTML = cart.map((item, idx) => `
      <div style="display: flex; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--line-gold);">
        <img src="assets/hero.webp" alt="${item.name}" style="width: 70px; height: 85px; object-fit: cover; border-radius: 8px;">
        <div style="flex: 1;">
          <h4 class="serif" style="color: #fff; font-size: 1.1rem;">${item.name}</h4>
          <p style="font-size: 0.82rem; color: var(--muted);">${item.size} · Made in Pakistan</p>
          <div style="display: flex; gap: 12px; margin-top: 8px; font-size: 0.82rem; color: var(--gold);">
            <span>Qty: <strong>${item.qty}</strong></span>
            <button type="button" style="background:none; color:#ff8585; text-decoration:underline;" onclick="removeCartItem(${idx})">Remove</button>
          </div>
        </div>
      </div>
    `).join('');
  };

  window.removeCartItem = (idx) => {
    cart.splice(idx, 1);
    saveCart();
  };

  const openDrawer = () => {
    if (cartDrawer) {
      cartDrawer.classList.add('open');
      cartDrawer.setAttribute('aria-hidden', 'false');
    }
    if (cartOverlay) cartOverlay.classList.add('open');
  };

  const closeDrawer = () => {
    if (cartDrawer) {
      cartDrawer.classList.remove('open');
      cartDrawer.setAttribute('aria-hidden', 'true');
    }
    if (cartOverlay) cartOverlay.classList.remove('open');
  };

  cartOpenBtns.forEach(b => b.addEventListener('click', openDrawer));
  if (cartClose) cartClose.addEventListener('click', closeDrawer);
  if (cartOverlay) cartOverlay.addEventListener('click', closeDrawer);

  document.querySelectorAll('[data-add]').forEach(btn => {
    btn.addEventListener('click', () => {
      const existing = cart.find(i => i.id === 'hair-oil-100');
      if (existing) {
        existing.qty = Math.min(99, existing.qty + 1);
      } else {
        cart.push({ id: 'hair-oil-100', name: 'Authentic Naturals Hair Oil', size: '100 ml', qty: 1 });
      }
      saveCart();
      openDrawer();
    });
  });

  if (checkoutBtn) {
    checkoutBtn.addEventListener('click', () => {
      if (cart.length === 0) {
        if (checkoutMsg) checkoutMsg.textContent = 'Please add a bottle to your bag first.';
        return;
      }
      const text = `Salam Authentic Naturals, I would like to order: ${cart.map(i => `${i.name} (${i.size}) x ${i.qty}`).join(', ')}. Please confirm price and delivery.`;
      if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
          if (checkoutMsg) checkoutMsg.textContent = '✓ Order enquiry copied! Paste it in your Facebook message.';
        });
      }
    });
  }

  renderCart();
});